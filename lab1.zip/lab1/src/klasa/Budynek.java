package klasa;

public class Budynek {
    String nazwa;
    int rok;
    int pietra;

    public Budynek(String nazwa, int rok, int pietra) {
        this.nazwa = nazwa;
        this.rok = rok;
        this.pietra = pietra;
    }
    public void dane()
    {
        System.out.println("Nazwa: "+nazwa+" Rok: "+rok+" Pietra: "+pietra);
    }
    public void ilelat()
    {
        System.out.println("Wiek budynku : "+(2022-rok));
    }

}
