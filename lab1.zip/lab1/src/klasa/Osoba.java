package klasa;

public class Osoba {
    String Imie;
    static String Nazwisko;
    int wiek;

public Osoba(){

}
    public Osoba(String Imie, String Nazwisko, int wiek) {
        this.Imie=Imie;
        this.Nazwisko=Nazwisko;
        this.wiek=wiek;
    }

    public Osoba(String Imie, int wiek) {
        this.Imie=Imie;
        this.wiek=wiek;
    }
    public void pokazDane(){
    System.out.println("Nazwisko: " +Nazwisko+" Imie: "+Imie+" Wiek: "+wiek);
    }
}
