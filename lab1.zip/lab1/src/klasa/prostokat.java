package klasa;

public class prostokat {
    int wysokosc;
    int szerokosc;

    public prostokat(int wysokosc,int szerokosc) {
        this.wysokosc = wysokosc;
        this.szerokosc=szerokosc;
    }
    public void Pole(){
        System.out.println("Pole "+ wysokosc*szerokosc);
    }
    public void Obwod(){
        System.out.println("Obwod "+(2*wysokosc+2*szerokosc));
    }
    public void przekatna(){
        System.out.println("Przekatna "+Math.sqrt(Math.pow(wysokosc,2)+Math.pow(szerokosc,2)));
    }

}
