package klasa;

import java.lang.reflect.Constructor;

public class Main {
    public static void main(String[] args) {
       // Osoba ob1=new Osoba("Adrian","Podraza",21);
   // ob1.pokazDane();
    prostokat ob2=new prostokat(10,20);
ob2.Pole();
ob2.Obwod();
ob2.przekatna();
        Budynek ob3=new Budynek("Tadeusz ",20,10);
        ob3.dane();
        ob3.ilelat();
    }

}


